                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2001983
Wall Gap/Cables Protector for IKEA Bekant (17 mm) by discove is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

I've made this simple thing to protect a gap between my Bekant table and the wall, so my cables don't get accidentally squished. =)

I've also made this thing wide (3cm) so it won't turn when the table is pushed slightly sideways. Also, it was made in 123D Design so I could learn it.

I've included my design files on [GitHub](https://github.com/gabfv/3d-cables-wall-gap-protector-ikea-bekant) if you want to modify it =).

# Print Settings

Printer: Monoprice Maker Select V2
Rafts: No
Supports: No
Resolution: 0.1 mm
Infill: 20%

Notes: 
I also had 0.4mm walls.